package com.example.mydiary.MODELS;

public class Model_folder {

    String folder_name;

    public String getFolder_name()
    {
        return folder_name;
    }

    public void setFolder_name(String folder_name)
    {
        this.folder_name = folder_name;
    }

    public Model_folder(String folder_name)
    {
        this.folder_name = folder_name;
    }
}
