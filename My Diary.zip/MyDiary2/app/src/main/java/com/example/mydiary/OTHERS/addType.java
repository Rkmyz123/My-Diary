package com.example.mydiary.OTHERS;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.mydiary.R;

public class addType extends AppCompatActivity {

    TextView eventtype;
    Button btnevent, btnchainevent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_type);
        btnevent=findViewById(R.id.btn_event);
        btnchainevent=findViewById(R.id.btn_chainevent);
        //btnchainevent.setVisibility(View.INVISIBLE);

        btnchainevent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(addType.this, chain_event.class);
                startActivity(intent);
            }
        });
    }


    public void btn_event(View view) {
        Intent intent = new Intent(addType.this, addEvent.class);
        startActivity(intent);


    }
}