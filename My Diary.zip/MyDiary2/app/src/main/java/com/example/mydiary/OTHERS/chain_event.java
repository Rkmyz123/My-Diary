package com.example.mydiary.OTHERS;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mydiary.DATA.DatabaseHelper;
import com.example.mydiary.MODELS.Model;
import com.example.mydiary.MODELS.chainmodel;
import com.example.mydiary.R;
import com.example.mydiary.RECYCLERSS.chainrecycler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;

public class chain_event extends AppCompatActivity implements DatePickerDialog.OnDateSetListener{

    EditText title_name, venue, descrip;
    Button btn_cancel, btn_done;
    RecyclerView RecyclerView;
    com.example.mydiary.RECYCLERSS.chainrecycler chainrecycler;
    ArrayList<chainmodel> arrayList = new ArrayList<>();
    ArrayList<Model> arrayList2 = new ArrayList<>();
 //   adapterRecycler adapterRecycler;


    TextView btn_date, btn_time;
    ListView listView;
    Spinner spinner2;
    String spinner_data;
    ArrayList<StringBuilder> data_list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chain_event);

        btn_done=findViewById(R.id.btndone);
        btn_cancel=findViewById(R.id.btncancel);
//         spinner2=findViewById(R.id.spinner2);
//        btn_date=findViewById(R.id.btn_selectDate_chain);
//        btn_time=findViewById(R.id.btn_selectTime_chain);
//        //  txttitle=findViewById(R.id.textView3);
//        listView = findViewById(R.id.listView);
        title_name = findViewById(R.id.txttitle_chain);
//        venue = findViewById(R.id.edittxt_venue_chain);
        descrip =findViewById(R.id.txttitle);
        RecyclerView= findViewById(R.id.chainrecycler);

        //      btn_LIST = findViewById(R.id.btn_addtolist);

        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        title_name.setText(name);
        RecyclerView.setLayoutManager(new LinearLayoutManager(this));


        DatabaseHelper myDbHelper = new DatabaseHelper(chain_event.this);
        try {
            myDbHelper.createDataBase();

        } catch (IOException ioe) {
            throw new Error("Unable to create database");
        }
        try {
            myDbHelper.openDataBase();
        } catch (SQLException sqle) {
            throw sqle;
        }
        myDbHelper.chainevents(null);
//        String[] data, data2 ;
//        data= new String[] {"Select Category","Wedding", "Datesheet", "Other Events"};
//        data2 = new String[] {"Select Type",
//                "Event"," Chain Event"};

        Cursor cursor = myDbHelper.entry("new_entry", null, null,
                null,null,null,null);
        while (cursor.moveToNext()){

            Model object = new Model(cursor.getString(0),cursor.getString(1),
                    cursor.getString(2), cursor.getString(3),null);
            arrayList2.add(object);
        }
//        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,data);
//       spinner2.setAdapter(arrayAdapter);
        chainrecycler=new chainrecycler(arrayList2);
        RecyclerView.setAdapter(chainrecycler);

        chainrecycler.setOnItemClickListener((position, title, venue, category, date) -> {

            ContentValues contentValues = new ContentValues();
            if (position==1){
           contentValues.put("Event_title",String.valueOf(title_name.getText()));
       //     contentValues.put("");
            contentValues.put("title", title);
            contentValues.put("venue",venue);
            contentValues.put("category",category);
            contentValues.put("date",date);
            myDbHelper.insert_abc("Chain_Event",contentValues);}
            else if (position==0){
                String[] ti= new String[] {title};
                myDbHelper.deleteRow("Chain_Event","title = ?",ti);
            }
    //        Toast.makeText(chain_event.this, "Event Added Successfully", Toast.LENGTH_SHORT).show();

        });

//        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                spinner_data = String.valueOf(spinner2.getSelectedItem());
//                StringBuilder stringBuilder =new StringBuilder();
//                stringBuilder.append(spinner_data);
//
//                btn_LIST.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//                        data_list.add(stringBuilder);
//                        ArrayAdapter<StringBuilder> arrayAdapter1 = new ArrayAdapter<>(chain_event.this,
//                                android.R.layout.simple_list_item_1,data_list);
//                        listView.setAdapter(arrayAdapter1);
//                    }
//                });
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> parent) {
//
//            }
//        });

        myDbHelper.create(null);

//        Cursor cursor = myDbHelper.entry("", null,null,null
//        ,null,null,null);

//        btn_date.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                showDatePickerDialog();
//            }
//        });
//        btn_time.setText(btn_time.getText());
//        times.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
////                Calendar calendar = Calendar.getInstance();
////                SimpleDateFormat format = new SimpleDateFormat(" d MMM yyyy HH:mm:ss ");
////                String time =  format.format(calendar.getTime());
//                times.setText(times.getText());
//            }
//        });

//        btn_LIST.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                ArrayList<String[]> arrayList =new ArrayList<>();
//
//                String[] d = new String[] {title.getText().toString().trim(),
//                venue.getText().toString().trim()};
//                arrayList.add(d);
//                listView.setAdapter((ListAdapter) arrayList);
//
//            }
//        });
        btn_done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ContentValues contentValues = new ContentValues();
      //          contentValues.put("title",String.valueOf(title.getText()));
//                contentValues.put("venue",String.valueOf(venue.getText()));
//                contentValues.put("date",String.valueOf(btn_date.getText()));
//                contentValues.put("time",String.valueOf(btn_time.getText()));
            //    myDbHelper.insert_abc("Chain_Event",contentValues);


                Toast.makeText(chain_event.this, "Chain Event Added Successfully", Toast.LENGTH_SHORT).show();
                //change code
                Intent intent = new Intent(chain_event.this, MainActivity.class);

                startActivity(intent);
            }
        });
        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //change code
                Intent intent = new Intent(chain_event.this, MainActivity.class);
                startActivity(intent);

            }
        });
    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        String date = month+1 + "/" + dayOfMonth + "/" + year;
        btn_date.setText(date);
    }
    private void showDatePickerDialog() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                this,
                Calendar.getInstance().get(Calendar.YEAR),
                Calendar.getInstance().get(Calendar.MONTH),
                Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();
    }
}