package com.example.mydiary.MODELS;

import android.widget.TextView;

public class Model {

    String f;

    public String getF()
    {
        return f;
    }

    public void setF(String f)
    {
        this.f = f;
    }

    public Model(String f)
    {
        this.f = f;
    }

    String t1 , t2,t3 ,txt_4,t5;


    public String getT1()
    {
        return t1;
    }

    public void setT1(String t1) {
        this.t1 = t1;
    }

    public String getT2() {
        return t2;
    }

    public void setT2(String t2) {
        this.t2 = t2;
    }

    public String getT3() {
        return t3;
    }

    public void setT3(String t3) {
        this.t3 = t3;
    }

    public String getTxt_4() {
        return txt_4;
    }

    public void setTxt_4(String txt_4) {
        this.txt_4 = txt_4;
    }

    public String getT5() {
        return t5;
    }

    public void setT5(String t5) {
        this.t5 = t5;
    }

    public Model(String t1, String t2, String t3, String txt_4, String t5) {
        this.t1 = t1;
        this.t2 = t2;
        this.t3 = t3;
        this.txt_4 = txt_4;
        this.t5 = t5;
    }
}
