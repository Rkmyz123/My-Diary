package com.example.mydiary.RECYCLERSS;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mydiary.MODELS.dates_model_class;
import com.example.mydiary.R;

import java.util.ArrayList;

public class vertical_date_recycler extends RecyclerView.Adapter<vertical_date_recycler.myviewholder>  {
    ArrayList<dates_model_class> data1;

    private OnItemClickListener2 mlistener;
    public interface OnItemClickListener2
    {
        void onButtonClick2(int position, String s);
    }

      public void setOnItemClickListener(OnItemClickListener2 listener2)
      {
          mlistener = listener2;
      }
    public vertical_date_recycler(ArrayList<dates_model_class> data1)
            
    {
        this.data1 = data1;
    }

    @NonNull
    @Override
    public vertical_date_recycler.myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.dates_vertically,parent,false);
        return new vertical_date_recycler.myviewholder(view, mlistener);
    }

    @Override
    public void onBindViewHolder(@NonNull vertical_date_recycler.myviewholder holder, int position) {

          holder.dates.setText(data1.get(position).getDates());
      //  holder.t1.setText(data1.get(position).getT1());
    }

    @Override
    public int getItemCount() 
    {
        return data1.size();
    }

    class myviewholder extends RecyclerView.ViewHolder {         // implements View.OnClickListener{

        TextView dates;
        public myviewholder(@NonNull View itemView, OnItemClickListener2 mlistener) {
            super(itemView);
            dates = itemView.findViewById(R.id.row_TXT_dates);

            dates.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v)
                {
                    String datess = String.valueOf(dates.getText());

                    mlistener.onButtonClick2(1, datess);
                }
            });
        }
    }

}
