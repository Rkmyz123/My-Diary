package com.example.mydiary.OTHERS;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mydiary.ADAPTER.adapterRecycler;
import com.example.mydiary.DATA.DatabaseHelper;
import com.example.mydiary.MODELS.Model;
import com.example.mydiary.MODELS.Model_folder;
import com.example.mydiary.MODELS.dates_model_class;
import com.example.mydiary.R;
import com.example.mydiary.RECYCLERSS.vertical_date_recycler;

import java.io.IOException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    TextView btndate, txt_chain_events;
    ImageButton btn_add, btn_bck, btn_forward;
    TextView txt_all, txt_birthday, txt_meetings, txt_anne, txtchain;
    RecyclerView recyclerView, recyclerView96;
    ArrayList<Model> arrayList = new ArrayList<>();
    ArrayList<Model> arrayList_f = new ArrayList<>();
    ArrayList<Model_folder> arrayList_folder = new ArrayList<>();
    ArrayList<dates_model_class> arrayList_date = new ArrayList<>();
    vertical_date_recycler verticalDateRecycler;
    adapterRecycler adapterRecycler;
    com.example.mydiary.ADAPTER.adapterRecycler.folder_adapter folder_adapter;
    RecyclerView recyclerView_dates;
    ImageButton btndelete, btnedit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btndate = findViewById(R.id.btn_date);
        btn_bck = findViewById(R.id.btn_back);
        btn_forward = findViewById(R.id.btn_forward);
        btn_add = findViewById(R.id.btn_ADD);
        txt_all = findViewById(R.id.txt_all);
        txt_birthday = findViewById(R.id.txt_birthday);
        txt_meetings = findViewById(R.id.txt_mestings);
        txt_anne = findViewById(R.id.txt_anee);
        txtchain = findViewById(R.id.button_chains);
        recyclerView = findViewById(R.id.recycler);
        recyclerView_dates = findViewById(R.id.recycler_date);

//        btndelete = findViewById(R.id.btn_delete);
//        btnedit= findViewById(R.id.btn_edit);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
//        recyclerView96.setLayoutManager(new LinearLayoutManager(this));
        txt_all.setBackgroundColor(Color.GREEN);

        recyclerView_dates.setLayoutManager(new LinearLayoutManager(this));

        DatabaseHelper myDbHelper = new DatabaseHelper(MainActivity.this);
        try {
            myDbHelper.createDataBase();

        } catch (IOException ioe) {
            throw new Error("Unable to create database");
        }
        try {
            myDbHelper.openDataBase();
        } catch (SQLException sqle) {
            throw sqle;
        }
        myDbHelper.create(null);
        myDbHelper.chainevents(null);
//        myDbHelper.drop();


        Cursor cursor = myDbHelper.entry("new_entry", null, null,
                null, null, null, null);
//       Cursor cursor1 = myDbHelper.entry("Chain_Event", null, null,
//                null,null,null,null);
        myDbHelper.dates(null);

  /*      ContentValues contentValues = new ContentValues();
        ContentValues contentValues1 = new ContentValues();ContentValues contentValues2 = new ContentValues();
        ContentValues contentValues3 = new ContentValues();ContentValues contentValues4 = new ContentValues();
        ContentValues contentValues5 = new ContentValues();ContentValues contentValues6 = new ContentValues();
        ContentValues contentValues7 = new ContentValues();ContentValues contentValues8 = new ContentValues();
        ContentValues contentValues9 = new ContentValues();ContentValues contentValues10 = new ContentValues();
        ContentValues contentValues11 = new ContentValues();ContentValues contentValues12 = new ContentValues();
        ContentValues contentValues13 = new ContentValues();ContentValues contentValues14 = new ContentValues();
        ContentValues contentValues15 = new ContentValues();ContentValues contentValues16 = new ContentValues();
        ContentValues contentValues17 = new ContentValues();ContentValues contentValues18 = new ContentValues();
        ContentValues contentValues19 = new ContentValues();ContentValues contentValues20 = new ContentValues();
        ContentValues contentValues21 = new ContentValues();ContentValues contentValues22 = new ContentValues();
        ContentValues contentValues23 = new ContentValues();ContentValues contentValues24 = new ContentValues();
        ContentValues contentValues25 = new ContentValues();ContentValues contentValues26 = new ContentValues();
        ContentValues contentValues27 = new ContentValues();ContentValues contentValues28 = new ContentValues();
        ContentValues contentValues29 = new ContentValues();ContentValues contentValues30 = new ContentValues();
*/

        //       adapterRecycler = new adapterRecycler(arrayList);


        Cursor cursor_date = myDbHelper.entry("dates", null, null,
                null, null, null, null);

        while (cursor_date.moveToNext()) {
            dates_model_class object_date = new dates_model_class(cursor_date.getString(1));
            arrayList_date.add(object_date);
        }
        verticalDateRecycler = new vertical_date_recycler(arrayList_date);
        recyclerView_dates.setAdapter(verticalDateRecycler);

        Calendar calendar = Calendar.getInstance();
        String date = DateFormat.getDateInstance().format(calendar.getTime());

        btndate.setText(date);
        btn_forward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = String.valueOf(btndate.getText());
                calendar.add(Calendar.DATE, 1);
                String date = DateFormat.getDateInstance().format(calendar.getTime());
                btndate.setText(date);
            }
        });

        btn_bck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = String.valueOf(btndate.getText());
                calendar.add(Calendar.DATE, -1);
                String date = DateFormat.getDateInstance().format(calendar.getTime());
                btndate.setText(date);
            }
        });

        btn_add.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, addType.class);
            startActivity(intent);

            ContentValues contentValues = new ContentValues();
            ContentValues contentValues1 = new ContentValues();
            ContentValues contentValues2 = new ContentValues();
            ContentValues contentValues3 = new ContentValues();
            ContentValues contentValues4 = new ContentValues();
            ContentValues contentValues5 = new ContentValues();
            ContentValues contentValues6 = new ContentValues();
            ContentValues contentValues7 = new ContentValues();
            ContentValues contentValues8 = new ContentValues();
            ContentValues contentValues9 = new ContentValues();
            ContentValues contentValues10 = new ContentValues();
            ContentValues contentValues11 = new ContentValues();
            ContentValues contentValues12 = new ContentValues();
            ContentValues contentValues13 = new ContentValues();
            ContentValues contentValues14 = new ContentValues();
            ContentValues contentValues15 = new ContentValues();
            ContentValues contentValues16 = new ContentValues();
            ContentValues contentValues17 = new ContentValues();
            ContentValues contentValues18 = new ContentValues();
            ContentValues contentValues19 = new ContentValues();
            ContentValues contentValues20 = new ContentValues();
            ContentValues contentValues21 = new ContentValues();
            ContentValues contentValues22 = new ContentValues();
            ContentValues contentValues23 = new ContentValues();
            ContentValues contentValues24 = new ContentValues();
            ContentValues contentValues25 = new ContentValues();
            ContentValues contentValues26 = new ContentValues();
            ContentValues contentValues27 = new ContentValues();
            ContentValues contentValues28 = new ContentValues();
            ContentValues contentValues29 = new ContentValues();
            ContentValues contentValues30 = new ContentValues();
            ContentValues contentValues31 = new ContentValues();


            contentValues.put("dates", 1);
            contentValues1.put("dates", 2);
            contentValues2.put("dates", 3);
            contentValues3.put("dates", 4);
            contentValues4.put("dates", 5);
            contentValues5.put("dates", 6);
            contentValues6.put("dates", 7);
            contentValues7.put("dates", 8);
            contentValues8.put("dates", 9);
            contentValues9.put("dates", 10);
            contentValues10.put("dates", 11);
            contentValues11.put("dates", 12);
            contentValues12.put("dates", 13);
            contentValues13.put("dates", 14);
            contentValues14.put("dates", 15);
            contentValues15.put("dates", 16);
            contentValues16.put("dates", 17);
            contentValues17.put("dates", 18);
            contentValues18.put("dates", 19);
            contentValues19.put("dates", 20);
            contentValues20.put("dates", 21);
            contentValues21.put("dates", 22);
            contentValues22.put("dates", 23);
            contentValues23.put("dates", 24);
            contentValues24.put("dates", 25);
            contentValues25.put("dates", 26);
            contentValues26.put("dates", 27);
            contentValues27.put("dates", 28);
            contentValues28.put("dates", 29);
            contentValues29.put("dates", 30);
            contentValues30.put("dates", 31);

            myDbHelper.insert_abc("dates", contentValues);
            myDbHelper.insert_abc("dates", contentValues1);
            myDbHelper.insert_abc("dates", contentValues2);
            myDbHelper.insert_abc("dates", contentValues3);
            myDbHelper.insert_abc("dates", contentValues4);
            myDbHelper.insert_abc("dates", contentValues5);
            myDbHelper.insert_abc("dates", contentValues6);
            myDbHelper.insert_abc("dates", contentValues7);
            myDbHelper.insert_abc("dates", contentValues8);
            myDbHelper.insert_abc("dates", contentValues9);
            myDbHelper.insert_abc("dates", contentValues10);
            myDbHelper.insert_abc("dates", contentValues11);
            myDbHelper.insert_abc("dates", contentValues12);
            myDbHelper.insert_abc("dates", contentValues13);
            myDbHelper.insert_abc("dates", contentValues14);
            myDbHelper.insert_abc("dates", contentValues15);
            myDbHelper.insert_abc("dates", contentValues16);
            myDbHelper.insert_abc("dates", contentValues17);
            myDbHelper.insert_abc("dates", contentValues18);
            myDbHelper.insert_abc("dates", contentValues19);
            myDbHelper.insert_abc("dates", contentValues20);
            myDbHelper.insert_abc("dates", contentValues21);
            myDbHelper.insert_abc("dates", contentValues22);
            myDbHelper.insert_abc("dates", contentValues23);
            myDbHelper.insert_abc("dates", contentValues24);
            myDbHelper.insert_abc("dates", contentValues25);
            myDbHelper.insert_abc("dates", contentValues26);
            myDbHelper.insert_abc("dates", contentValues27);
            myDbHelper.insert_abc("dates", contentValues28);
            myDbHelper.insert_abc("dates", contentValues29);
            myDbHelper.insert_abc("dates", contentValues30);


        });


        txt_birthday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt_birthday.setBackgroundColor(Color.GREEN);
                txt_all.setBackgroundColor(Color.WHITE);
                txt_meetings.setBackgroundColor(Color.WHITE);
                txt_anne.setBackgroundColor(Color.WHITE);
                txtchain.setBackgroundColor(Color.WHITE);

                birthday_function();
            }
        });

        txt_all.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt_birthday.setBackgroundColor(Color.WHITE);
                txt_all.setBackgroundColor(Color.GREEN);
                txt_meetings.setBackgroundColor(Color.WHITE);
                txt_anne.setBackgroundColor(Color.WHITE);
                txtchain.setBackgroundColor(Color.WHITE);
                alldata_fun();

            }
        });
        txt_meetings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt_birthday.setBackgroundColor(Color.WHITE);
                txt_all.setBackgroundColor(Color.WHITE);
                txt_meetings.setBackgroundColor(Color.GREEN);
                txt_anne.setBackgroundColor(Color.WHITE);
                txtchain.setBackgroundColor(Color.WHITE);

                weddings_function();
            }
        });
        txt_anne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt_birthday.setBackgroundColor(Color.WHITE);
                txt_all.setBackgroundColor(Color.WHITE);
                txt_meetings.setBackgroundColor(Color.WHITE);
                txt_anne.setBackgroundColor(Color.GREEN);
                txtchain.setBackgroundColor(Color.WHITE);

                anniversiry_function();
            }
        });
        txtchain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt_birthday.setBackgroundColor(Color.WHITE);
                txt_all.setBackgroundColor(Color.WHITE);
                txt_meetings.setBackgroundColor(Color.WHITE);
                txt_anne.setBackgroundColor(Color.WHITE);
                txtchain.setBackgroundColor(Color.GREEN);

                Toast.makeText(MainActivity.this, "chain", Toast.LENGTH_SHORT).show();
//                Cursor cursor1 = myDbHelper.entry(
//                        "Chain_Event", null,
//                        null,
//                        null,null,null,null);
                Cursor cursor1 = myDbHelper.getinto("", null, null);
                arrayList_folder.clear();
                while (cursor1.moveToNext()) {
                    Model_folder object = new Model_folder(cursor1.getString(0));
                    arrayList_folder.add(object);
                }
                folder_adapter = new adapterRecycler.folder_adapter(arrayList_folder);
                recyclerView.setAdapter(folder_adapter);
                folder_adapter.setOnItemClickListener(new com.example.mydiary.ADAPTER.adapterRecycler.folder_adapter.itemClickListener() {
                    @Override
                    public void onfolderclick(int position, String s) {

                        String nn = "";
                        String[] title = new String[]{s};
                        String n = title[0];
                        Cursor cursor_f = myDbHelper.entry("Chain_Event", null, "Event_title = ?",
                                title, n, null, null);

                        arrayList_f.clear();
                        while (cursor_f.moveToNext()) {
                            Model object = new Model(cursor_f.getString(0), cursor_f.getString(1),
                                    cursor_f.getString(2), cursor_f.getString(3), cursor_f.getString(4));
                            arrayList_f.add(object);
                        }
                        adapterRecycler adapterRecycler = new adapterRecycler(arrayList_f);
                        recyclerView.setAdapter(adapterRecycler);
                    }
                });
                folder_adapter.setOnItemClickListener_D(new com.example.mydiary.ADAPTER.adapterRecycler.folder_adapter.itemClickListener_D() {
                    @Override
                    public void ondeleteClick(int position, String s) {
                        String[] title = new String[]{s};
                        Toast.makeText(MainActivity.this, "Record deleted", Toast.LENGTH_SHORT).show();
                        myDbHelper.deleteRow("Chain_Event", "Event_title = ?", title);
                    }
                });
                folder_adapter.setEditClick(new com.example.mydiary.ADAPTER.adapterRecycler.folder_adapter.itemEdit() {
                    @Override
                    public void onEditClick(String edit) {
                        Intent intent = new Intent(MainActivity.this, chain_event.class);
                        intent.putExtra("name", edit);
                        startActivity(intent);
                    }
                });
            }
        });

        verticalDateRecycler.setOnItemClickListener(new vertical_date_recycler.OnItemClickListener2() {
            @Override
            public void onButtonClick2(int position, String s)
            {
                onDateSelect(position, s);
            }
        });
        alldata_fun();
    }

    private void other_function() {
        DatabaseHelper myDbHelper = new DatabaseHelper(MainActivity.this);
        try {
            myDbHelper.createDataBase();

        } catch (IOException ioe) {
            throw new Error("Unable to create database");
        }
        try {
            myDbHelper.openDataBase();
        } catch (SQLException sqle) {
            throw sqle;
        }

        String[] other = new String[]{"Other Events"};
        Cursor cursor_b = myDbHelper.entry(
                "new_entry",
                null,
                "category = ?",
                other,
                null,
                null,
                null);
        cursor_b.moveToFirst();
        arrayList.clear();
        while (cursor_b.moveToNext()) {
            Model object = new Model(
                    cursor_b.getString(0),
                    cursor_b.getString(1),
                    cursor_b.getString(2),
                    cursor_b.getString(3),
                    cursor_b.getString(4));
            //          arrayList.remove(object);
            arrayList.add(object);
        }
        adapterRecycler adapterRecycler = new adapterRecycler(arrayList);
        recyclerView.setAdapter(adapterRecycler);

        adapterRecycler.setOnItemClickListener((position, s) -> {
            String[] title = new String[]{s};
            Toast.makeText(MainActivity.this, "Record deleted", Toast.LENGTH_SHORT).show();
            myDbHelper.deleteRow("new_entry", "title = ?", title);
        });

        adapterRecycler.setEditClick(new adapterRecycler.itemEdit() {
            @Override
            public void onEditClick(String edit_title, String edit_venue, String edit_category) {
                Intent intent = new Intent(MainActivity.this, addEvent.class);
                intent.putExtra("title", edit_title);
                intent.putExtra("ven", edit_venue);
                intent.putExtra("cate", edit_category);
                startActivity(intent);
            }
        });
    }

    private void weddings_function() {
        DatabaseHelper myDbHelper = new DatabaseHelper(MainActivity.this);
        try {
            myDbHelper.createDataBase();

        } catch (IOException ioe) {
            throw new Error("Unable to create database");
        }
        try {
            myDbHelper.openDataBase();
        } catch (SQLException sqle) {
            throw sqle;
        }

        arrayList.clear();
        String[] wed = new String[]{"Meetings"};
        Cursor cursor_b = myDbHelper.entry(
                "new_entry",
                null,
                "category = ?",
                wed,
                null,
                null,
                null);
        cursor_b.moveToFirst();
        while (cursor_b.moveToNext()) {
            Model object = new Model(
                    cursor_b.getString(0),
                    cursor_b.getString(1),
                    cursor_b.getString(2),
                    cursor_b.getString(3),
                    cursor_b.getString(4));
            arrayList.add(object);
        }
        adapterRecycler adapterRecycler = new adapterRecycler(arrayList);
        // adapterRecycler.notify();
        adapterRecycler.notifyItemChanged(0);
        recyclerView.setAdapter(adapterRecycler);

        adapterRecycler.setOnItemClickListener((position, s) -> {
            String[] title = new String[]{s};
            Toast.makeText(MainActivity.this, "Record deleted", Toast.LENGTH_SHORT).show();
            myDbHelper.deleteRow("new_entry", "title = ?", title);
        });

        adapterRecycler.setEditClick(new adapterRecycler.itemEdit() {
            @Override
            public void onEditClick(String edit_title, String edit_venue, String edit_category) {
                Intent intent = new Intent(MainActivity.this, addEvent.class);
                intent.putExtra("title", edit_title);
                intent.putExtra("ven", edit_venue);
                intent.putExtra("cate", edit_category);
                startActivity(intent);
            }

        });
    }

    private void alldata_fun() {
        DatabaseHelper myDbHelper = new DatabaseHelper(MainActivity.this);
        try {
            myDbHelper.createDataBase();

        } catch (IOException ioe) {
            throw new Error("Unable to create database");
        }
        try {
            myDbHelper.openDataBase();
        } catch (SQLException sqle) {
            throw sqle;
        }
        Cursor cursor;
        cursor = myDbHelper.entry(
                "new_entry",
                null,
                null,
                null,
                null,
                null,
                null);
        cursor.moveToFirst();
        arrayList.clear();
        while (cursor.moveToNext()) {

            Model object = new Model(cursor.getString(0), cursor.getString(1),
                    cursor.getString(2), cursor.getString(3), cursor.getString(4));
            arrayList.add(object);
        }
        adapterRecycler adapterRecycler = new adapterRecycler(arrayList);
        recyclerView.setAdapter(adapterRecycler);


        //    recyclerView.notifyItemRangeRemoved(0, size);

        adapterRecycler.setOnItemClickListener(new adapterRecycler.itemClickListener() {
            @Override
            public void ondeleteClick(int position, String s) {

                String[] title = new String[]{s};
                Toast.makeText(MainActivity.this, "Record deleted", Toast.LENGTH_SHORT).show();
                myDbHelper.deleteRow("new_entry", "title = ?", title);
//               int size = arrayList.size();
//
//                arrayList.clear();
//                adapterRecycler.notifyItemRemoved(size);
                //    adapterRecycler.notifyItemRemoved(size);
            }
        });
        adapterRecycler.setEditClick(new adapterRecycler.itemEdit() {
            @Override
            public void onEditClick(String edit_title, String edit_venue, String edit_category) {
                Intent intent = new Intent(MainActivity.this, addEvent.class);
                intent.putExtra("title", edit_title);
                intent.putExtra("ven", edit_venue);
                intent.putExtra("cate", edit_category);
                startActivity(intent);
            }

        });


//        adapterRecycler adapterRecycler = new adapterRecycler(arrayList);
//        recyclerView.setAdapter(adapterRecycler);
    }

    private void birthday_function() {

        DatabaseHelper myDbHelper = new DatabaseHelper(MainActivity.this);
        try {
            myDbHelper.createDataBase();

        } catch (IOException ioe) {
            throw new Error("Unable to create database");
        }
        try {
            myDbHelper.openDataBase();
        } catch (SQLException sqle)
        {
            throw sqle;
        }

        String[] birth = new String[]{"Birthday"};
        Cursor cursor_b = myDbHelper.entry(
                "new_entry",
                null,
                "category = ?",
                birth,
                null,
                null,
                null);
        cursor_b.moveToFirst();
        arrayList.clear();
        while (cursor_b.moveToNext()) {
            Model object = new Model(
                    cursor_b.getString(0),
                    cursor_b.getString(1),
                    cursor_b.getString(2),
                    cursor_b.getString(3),
                    cursor_b.getString(4));
            arrayList.add(object);
        }
        adapterRecycler adapterRecycler = new adapterRecycler(arrayList);
        recyclerView.setAdapter(adapterRecycler);

        adapterRecycler.setOnItemClickListener((position, s) -> {
            String[] title = new String[]{s};
            Toast.makeText(MainActivity.this, "Record deleted", Toast.LENGTH_SHORT).show();
            myDbHelper.deleteRow("new_entry", "title = ?", title);
        });

        adapterRecycler.setEditClick(new adapterRecycler.itemEdit() {
            @Override
            public void onEditClick(String edit_title, String edit_venue, String edit_category) {
                Intent intent = new Intent(MainActivity.this, addEvent.class);
                intent.putExtra("title", edit_title);
                intent.putExtra("ven", edit_venue);
                intent.putExtra("cate", edit_category);
                startActivity(intent);
            }

        });

    }

    private void anniversiry_function() {

        DatabaseHelper myDbHelper = new DatabaseHelper(MainActivity.this);
        try {
            myDbHelper.createDataBase();

        } catch (IOException ioe) {
            throw new Error("Unable to create database");
        }
        try {
            myDbHelper.openDataBase();
        } catch (SQLException sqle) {
            throw sqle;
        }

        String[] birth = new String[]{"Anniversary"};
        Cursor cursor_b = myDbHelper.entry(
                "new_entry",
                null,
                "category = ?",
                birth,
                null,
                null,
                null);
        cursor_b.moveToFirst();
        arrayList.clear();
        while (cursor_b.moveToNext()) {
            Model object = new Model(
                    cursor_b.getString(0),
                    cursor_b.getString(1),
                    cursor_b.getString(2),
                    cursor_b.getString(3),
                    cursor_b.getString(4));
            arrayList.add(object);
        }
        adapterRecycler adapterRecycler = new adapterRecycler(arrayList);
        recyclerView.setAdapter(adapterRecycler);

        adapterRecycler.setOnItemClickListener((position, s) -> {
            String[] title = new String[]{s};
            Toast.makeText(MainActivity.this, "Record deleted", Toast.LENGTH_SHORT).show();
            myDbHelper.deleteRow("new_entry", "title = ?", title);
        });

        adapterRecycler.setEditClick(new adapterRecycler.itemEdit() {
            @Override
            public void onEditClick(String edit_title, String edit_venue, String edit_category) {
                Intent intent = new Intent(MainActivity.this, addEvent.class);
                intent.putExtra("title", edit_title);
                intent.putExtra("ven", edit_venue);
                intent.putExtra("cate", edit_category);
                startActivity(intent);
            }

        });

    }

    void onDateSelect(int p, String s) {

        Cursor cursor;
    }

    @Override
    protected void onResume() {

        super.onResume();
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(MainActivity.this, MainActivity.class);
        startActivity(intent);
        super.onBackPressed();
    }
}