package com.example.mydiary.OTHERS;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.SQLException;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.mydiary.DATA.DatabaseHelper;
import com.example.mydiary.R;

import java.io.IOException;
import java.util.Calendar;

public class addEvent extends AppCompatActivity implements DatePickerDialog.OnDateSetListener {
    TextView btnselectdate;
    Button btnselecttime, btnsave;
    TextView txttitle;
    EditText times;
    Spinner spinner;
    EditText txt_title, txt_venue;
    String spinner_data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);
        btnsave=findViewById(R.id.btn_save);
        btnselectdate=findViewById(R.id.btn_selectDate);
        times=findViewById(R.id.btn_selectTime);
        //  txttitle=findViewById(R.id.textView3);
        spinner = findViewById(R.id.spinner);
        txt_venue = findViewById(R.id.edittxt_venue);
        txttitle =findViewById(R.id.txttitle);

        DatabaseHelper myDbHelper = new DatabaseHelper(addEvent.this);
        try {
            myDbHelper.createDataBase();

             }
        catch (IOException ioe)
        {
            throw new Error("Unable to create database");
        }
        try {
            myDbHelper.openDataBase();
             }

        catch (SQLException sqle) {
            throw sqle;
            }

        Intent intent = getIntent();
        String my = intent.getStringExtra("title");
        String my2 = intent.getStringExtra("ven");
        String my3 = intent.getStringExtra("cate");

        txttitle.setText(my);
        txt_venue.setText(my2);

        String[] data, data2 ;
        data= new String[] {"Select Category","Birthday", "Weddings", "Anniversary"};

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,data);
        spinner.setAdapter(arrayAdapter);

spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        spinner_data = String.valueOf(spinner.getSelectedItem());
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
});
        myDbHelper.create(null);

//        Cursor cursor = myDbHelper.entry("", null,null,null
//        ,null,null,null);

        btnselectdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                showDatePickerDialog();
            }
        });
 //       times.setText(times.getText());
//        times.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//              Calendar calendar = Calendar.getInstance();
//               SimpleDateFormat format = new SimpleDateFormat(" d MMM yyyy HH:mm:ss ");
//                String time =  format.format(calendar.getTime());
//                times.setText(times.getText());
//            }
//        });
//        times.setText( "" + selectedHour + ":" + selectedMinute);
        times.setText(times.getText());
        times.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Calendar mcurrentTime = Calendar.getInstance();
                int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
                int minute = mcurrentTime.get(Calendar.MINUTE);
                TimePickerDialog mTimePicker;
                mTimePicker = new TimePickerDialog(addEvent.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                        times.setText( selectedHour + ":" + selectedMinute);
                    }
                }, hour, minute, false);//Yes 24 hour time
                mTimePicker.setTitle("Select Time");
                mTimePicker.show();

            }
        });

        btnsave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ContentValues contentValues = new ContentValues();
                contentValues.put("title",String.valueOf(txttitle.getText()));
                contentValues.put("venue",String.valueOf(txt_venue.getText()));
                contentValues.put("category",spinner_data);
                contentValues.put("date",String.valueOf(btnselectdate.getText()));
                contentValues.put("time",String.valueOf(times.getText()));
                 myDbHelper.insertIntoEntry(contentValues);
                
                Toast.makeText(addEvent.this, "Event Added Successfully", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(addEvent.this, MainActivity.class);
                startActivity(intent);
            
            }
        });
    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        String date = month+1 + "/" + dayOfMonth + "/" + year;
        btnselectdate.setText(date);
    }
    private void showDatePickerDialog()
    {
        DatePickerDialog datePickerDialog = new DatePickerDialog(this, this,
                Calendar.getInstance().get(Calendar.YEAR),
                Calendar.getInstance().get(Calendar.LONG_FORMAT),
                Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();
    }

}