package com.example.mydiary.ADAPTER;

import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mydiary.MODELS.Model;
import com.example.mydiary.MODELS.Model_folder;
import com.example.mydiary.R;

import java.util.ArrayList;


public class adapterRecycler extends RecyclerView.Adapter<adapterRecycler.myviewholder>  {
    ArrayList<Model> data1;
  private itemClickListener deletes;
  private itemEdit edit;
  

    public interface itemClickListener{
        void ondeleteClick(int position, String s);
    }
    public interface itemEdit{
        void onEditClick(String edit_title,String edit_venue,String edit_category);
    }

    public void setOnItemClickListener(itemClickListener listener2){  deletes = listener2;  }
    public void setEditClick(itemEdit listener){  edit = listener;  }

    public adapterRecycler(ArrayList<Model> data1) {
        this.data1 = data1;
        //  this.data2 = data2;
    }

    @NonNull
    @Override
    public myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.addevent_row,parent,false);
        //  View view1 = LayoutInflater.from(parent.getContext()).inflate(R.layout.row2,parent,false);
        return new myviewholder(view,deletes, edit);
    }

    @Override
    public void onBindViewHolder(@NonNull myviewholder holder, int position) {

        //  holder.t.setText(data.get(position).getText());
        holder.t1.setText(data1.get(position).getT1());
        holder.t2.setText(data1.get(position).getT2());
        holder.t3.setText(data1.get(position).getT3());
        holder.t4.setText(data1.get(position).getTxt_4());
        holder.t5.setText(data1.get(position).getT5());
      //  holder.t5.setText(data1.get(position).getT5());
    }

    @Override
    public int getItemCount() {
        return data1.size();

    }

    class myviewholder extends RecyclerView.ViewHolder {         // implements View.OnClickListener{

        TextView t1, t2, t3, t4, t5;
        ImageButton btndelte, btn_edit;


        public myviewholder(@NonNull View itemView, final itemClickListener delete,
                            final itemEdit edit) {
            super(itemView);
            t1 = itemView.findViewById(R.id.t1);
            t2 = itemView.findViewById(R.id.t2);
            t3 = itemView.findViewById(R.id.t3);
            t4= itemView.findViewById(R.id.t4);
            t5=itemView.findViewById(R.id.t5);
            btndelte = itemView.findViewById(R.id.btn_deleteMain);
            btn_edit = itemView.findViewById(R.id.btn_edit);

            btndelte.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    delete.ondeleteClick(0,t1.getText().toString());
                }
            });
            btn_edit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    edit.onEditClick(t1.getText().toString(), t2.getText().toString(),
                            t3.getText().toString());
                //    notifyItemChanged(0, data1.size());
                }
            });
     //       t5 = itemView.findViewById(R.id.textView12);

//            t1.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    int position = getLayoutPosition();
//                    String s = String.valueOf(t.getText());
//                    t.setFocusable(true);
//                    //  t.setText("aaa");
//                    //   if (position != RecyclerView.NO_POSITION) {
//                    listener2.onButtonClick2(position, s);
//
//                }
//            });
            //         t5 = itemView.findViewById(R.id.textView11);
//           itemView.setOnClickListener((View.OnClickListener) btn);
        }
        public void clear() {
            int size = data1.size();
            data1.clear();
            notifyItemRangeRemoved(0, size);
        }
    }

    public static class folder_adapter extends RecyclerView.Adapter<folder_adapter.myviewholder>  {
        ArrayList<Model_folder> data1;
        private itemClickListener folder_click;
        private itemClickListener_D deletes;
        private itemEdit edit;
        //   private OnItemClickListener2 mlistener;
        //   AssetManager asset = getAssets() ;
        AssetFileDescriptor descriptor = null;
        final MediaPlayer mediaPlayer = new MediaPlayer();
    //ArrayList<Model>  data2;
    
        public interface itemClickListener{
            void onfolderclick(int position, String s);
        }
        public interface itemEdit{
            void onEditClick(String edit);
        }
        public interface itemClickListener_D{
            void ondeleteClick(int position, String s);
        }
    
        public void setOnItemClickListener(itemClickListener listener2)
        {
            folder_click = listener2;
        }
        public void setOnItemClickListener_D(itemClickListener_D listener2)
        {
            deletes = listener2;
        }
        public void setEditClick(itemEdit listener)
        {
            edit = listener;
        }
    
        public folder_adapter(ArrayList<Model_folder> data1) {
            this.data1 = data1;
            //  this.data2 = data2;
        }
    
        @NonNull
        @Override
        public myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
    
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_all_folders,parent,false);
            //  View view1 = LayoutInflater.from(parent.getContext()).inflate(R.layout.row2,parent,false);
            return new myviewholder(view,folder_click, deletes, edit);
        }
    
        @Override
        public void onBindViewHolder(@NonNull myviewholder holder, int position) {
    
            //  holder.t.setText(data.get(position).getText());
            holder.f.setText(data1.get(position).getFolder_name());
        }
    
        @Override
        public int getItemCount() {
            return data1.size();
    
        }
    
        class myviewholder extends RecyclerView.ViewHolder {         // implements View.OnClickListener{
    
            TextView t1, t2, t3, t4, t5,f;
            ImageButton btndelte, btn_edit;
    
    
            public myviewholder(@NonNull View itemView, final itemClickListener folder, final itemClickListener_D deleted,
                                final itemEdit edit) {
                super(itemView);
                f = itemView.findViewById(R.id.foldertext);
                btndelte= itemView.findViewById(R.id.imageButton_folderDel);
                btn_edit= itemView.findViewById(R.id.imageButton_folderEdit);
    
                f.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        folder.onfolderclick(0, f.getText().toString());
                    }
                });
                btndelte.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        deleted.ondeleteClick(0,f.getText().toString());
                    }
                });
                btn_edit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        edit.onEditClick(f.getText().toString());
                    }
                });
          //      btn_edit = itemView.findViewById(R.id.btn_edit);
    
            }
        }
    }
}

