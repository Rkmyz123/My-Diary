package com.example.mydiary.RECYCLERSS;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mydiary.MODELS.Model;
import com.example.mydiary.R;

import java.util.ArrayList;


public class chainrecycler extends RecyclerView.Adapter<chainrecycler.myviewholder>  {
    ArrayList<Model> data1;
    private itemClickListener checkB;
    private itemEdit edit;

    public interface itemClickListener
    {
        void onCheckBox(int position, String title,String venue,
                        String category, String date);
    }
    public interface itemEdit
    {
        void onEditClick(String edit);
    }

    public void setOnItemClickListener(itemClickListener listener2)
    {
        checkB = listener2;
    }
    public void setEditClick(itemEdit listener)
    {
        edit = listener;  
    }

    public chainrecycler(ArrayList<Model> data1) 
    {
        this.data1 = data1;
        
    }

    @NonNull
    @Override
    public myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chainevent_row,parent,false);
        return new myviewholder(view,checkB, edit);

    }

    @Override
    public void onBindViewHolder(@NonNull myviewholder holder, int position) {

        //  holder.t.setText(data.get(position).getText());
        holder.t1.setText(data1.get(position).getT1());
        holder.t2.setText(data1.get(position).getT2());
        holder.t3.setText(data1.get(position).getT3());
        holder.t4.setText(data1.get(position).getTxt_4());
        //  holder.t5.setText(data1.get(position).getT5());
    }

    @Override
    public int getItemCount() {
        return data1.size();

    }

    class myviewholder extends RecyclerView.ViewHolder {         // implements View.OnClickListener{

        TextView t1, t2
        , t3, t4, t5;
        ImageButton btndelte, btn_edit;
        CheckBox checkBox;


        public myviewholder(@NonNull View itemView, final itemClickListener checkbox,
                            final itemEdit edit) {
            super(itemView);
            t1 = itemView.findViewById(R.id.t1);
            t2 = itemView.findViewById(R.id.t2);
            t3 = itemView.findViewById(R.id.t3);
            t4= itemView.findViewById(R.id.t4);
            checkBox = itemView.findViewById(R.id.checkBox);
                  
            checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked) {
                        checkbox.onCheckBox(1, t1.getText().toString(),
                                t2.getText().toString(), t3.getText().toString(),
                                t4.getText().toString());
                    }
                    if (!isChecked){
                        checkbox.onCheckBox(0, t1.getText().toString(),
                                t2.getText().toString(), t3.getText().toString(),
                                t4.getText().toString());
                    }
                }
            });
//            btndelte = itemView.findViewById(R.id.btn_delete);
//            btn_edit = itemView.findViewById(R.id.btn_edit);

//            btndelte.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    delete.ondeleteClick(0,t1.getText().toString());
//                }
//            });
//            btn_edit.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    edit.onEditClick(t1.getText().toString());
//                }
//            });
            //       t5 = itemView.findViewById(R.id.textView12);

//            t1.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    int position = getLayoutPosition();
//                    String s = String.valueOf(t.getText());
//                    t.setFocusable(true);
//                    //  t.setText("aaa");
//                    //   if (position != RecyclerView.NO_POSITION) {
//                    listener2.onButtonClick2(position, s);
//
//                }
//            });
            //         t5 = itemView.findViewById(R.id.textView11);
//           itemView.setOnClickListener((View.OnClickListener) btn);
        }
    }
}

