package com.example.mydiary.DATA;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class DatabaseHelper extends SQLiteOpenHelper {


    String DB_PATH = null;
    private static String DB_NAME = "diaryDB.db";
    private SQLiteDatabase myDataBase;
    private final Context myContext;
    Cursor c3, c2;

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, 10);
        this.myContext = context;
        this.DB_PATH = "/data/data/" + context.getPackageName() + "/" + "databases/";
        Log.e("Path 1", DB_PATH);
    }


    public void createDataBase() throws IOException {
        boolean dbExist = checkDataBase();
        if (dbExist) {
        } else {
            this.getReadableDatabase();
            try {
                copyDataBase();
            } catch (IOException e) {
                throw new Error("Error copying database");
            }
        }
    }

    private boolean checkDataBase() {
        SQLiteDatabase checkDB = null;
        try {
            String myPath = DB_PATH + DB_NAME;
            checkDB = SQLiteDatabase.openDatabase(myPath, null, SQLiteDatabase.OPEN_READONLY);
        } catch (SQLiteException e) {
        }
        if (checkDB != null) {
            checkDB.close();
        }
        return checkDB != null ? true : false;
    }

    private void copyDataBase() throws IOException {
        InputStream myInput = myContext.getAssets().open(DB_NAME);
        String outFileName = DB_PATH + DB_NAME;
        OutputStream myOutput = new FileOutputStream(outFileName);
        byte[] buffer = new byte[10];
        int length;
        while ((length = myInput.read(buffer)) > 0) {
            myOutput.write(buffer, 0, length);
        }
        myOutput.flush();
        myOutput.close();
        myInput.close();
    }

    public void openDataBase() throws SQLException {
        String myPath = DB_PATH + DB_NAME;
        //  myDataBase = SQLiteDatabase.openDatabase(myPath, null, SQLiteDatabase.OPEN_READONLY);
        myDataBase = SQLiteDatabase.openDatabase(myPath, null, SQLiteDatabase.OPEN_READWRITE);
    }

    @Override
    public synchronized void close() {
        if (myDataBase != null)
            myDataBase.close();
        super.close();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (newVersion > oldVersion)
            try {
                copyDataBase();
            } catch (IOException e) {
                e.printStackTrace();
            }
    }

    public Cursor en(String table, String[] columns, String selection, String[] selectionArgs, String groupBy, String having, String orderBy) {
        return myDataBase.query("new_entry", null, null, null, null, null, null);
    }

    public Cursor query2(String table, String[] columns, String selection, String[] selectionArgs, String groupBy, String having, String orderBy) {
        return myDataBase.query("chain_event", null, selection, null, null, null, null);

    }

    public Cursor attendance(String table, String[] columns, String selection, String[] selectionArgs, String groupBy, String having, String orderBy) {
        return myDataBase.query(table, null, selection, selectionArgs, null, null, null);

    }

    public Cursor entry(String table, String[] columns, String selection, String[] selectionArgs, String groupBy, String having, String orderBy) {
        return myDataBase.query(table, columns, selection, selectionArgs, null, null, null);
    }
    public Cursor getinto(String table, String[] c, String selection) {
        return myDataBase.rawQuery("Select DISTINCT Event_title FROM Chain_Event", c, null);

    }

    public void create(String s) {
        myDataBase.execSQL("CREATE TABLE IF NOT EXISTS new_entry(title TEXT, venue TEXT, category TEXT, date TEXT, time TEXT);");
    }
    public void create_regform(String s) {
        myDataBase.execSQL("CREATE TABLE IF NOT EXISTS registration_form(name TEXT, class TEXT,reg_no NUMERIC UNIQUE,phone NUMERIC UNIQUE, email TEXT UNIQUE, pass TEXT, profile_pic BLOB);");
    }
    public void allEvents(String s) {
        myDataBase.execSQL("CREATE TABLE IF NOT EXISTS sdawdaw(ID Integer primary key AUTOIncrement NOT NULL,all_event TEXT, reg_no TEXT, class TEXT, attendance TEXT, date TEXT );");
    }
    public void dates(String s) {
        myDataBase.execSQL("CREATE TABLE IF NOT EXISTS dates(ID Integer primary key AUTOIncrement NOT NULL,dates TEXT);");
    }
    public void chainevents(String s) {
        myDataBase.execSQL("CREATE TABLE IF NOT EXISTS Chain_Event(Event_title TEXT,title TEXT, venue TEXT, category TEXT, date TEXT, time TEXT);");
    }

    public Cursor attendance(String table, String[] columns) {
        return myDataBase.rawQuery(table, columns);
    }
    public long insertIntoEntry(ContentValues contentValues) {
        return myDataBase.insert("new_entry", null, contentValues);
    }
    public long insert_abc(String table, ContentValues contentValues) {
        return myDataBase.insert(table, null, contentValues);
    }
    public long insert_StudentReport(String table,ContentValues contentValues) {
        return myDataBase.insert(table, null, contentValues);
    }
    public long insert_SystemReport(ContentValues contentValues) {
        return myDataBase.insert("System_reports", null, contentValues);
    }
    public void update1(String[] a) {
        myDataBase.execSQL("Update attendance Set profile_pic = ? ",a);
    }
    public long update_attendance(String[] a, ContentValues values) {
        return myDataBase.update("attendance",values,"name = ? and date = ?",a );
    }
    public int delete_Attendance(String table, String where, String[] whereArgs) {
        return myDataBase.delete(table, "name = ? and date = ? ", whereArgs);
    }
    public long profile (ContentValues contentValues, String[] a){
        return myDataBase.update("registration_form",contentValues,"reg_no = ?",a);
    }

    public long insert10(String table, ContentValues contentValues)
    {

        return myDataBase.insert(table, null, contentValues);
    }

    public int delete()
    {
        return myDataBase.delete("", null, null);
    }

    public int deleteRow(String table, String where, String[] whereArgs) {
        return myDataBase.delete(table, where, whereArgs);
    }

    public void drop(String date)
    {
        myDataBase.execSQL("DROP TABLE IF EXISTs chain_event");
    }
    public void drop2()
    {
        myDataBase.execSQL("DROP TABLE IF EXISTs attendances3");
    }


//    public Cursor insert(String table , String[] col , ContentValues values){
//        return myDataBase.insert(table , col , values);
//    }
}