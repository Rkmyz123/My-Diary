package com.example.mydiary.MODELS;

public class dates_model_class {

    String dates;

    public dates_model_class(String dates) {
        this.dates = dates;
    }

    public String getDates() {
        return dates;
    }

    public void setDates(String dates) {
        this.dates = dates;
    }
}
